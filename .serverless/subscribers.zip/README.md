#  TypeScript-NodeJs-Yarn-With-Abstract-Controller

1. `yarn install`
2. `yarn watch`

# Thanks to Toptal Series By Marcos Henrique da Silva