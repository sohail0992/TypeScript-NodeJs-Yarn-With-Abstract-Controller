#  TypeScript-NodeJs-Yarn-With-Abstract-Controller

1. `yarn install`
2. `yarn watch`

# Example env
```
TOKEN=''
MONGO_URL=''
SERVERLESS=true // if you want to run it as serverless

```


# Thanks to Toptal Series By Marcos Henrique da Silva
